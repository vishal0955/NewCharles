import React from "react";

const NotFound = () => {
  return <div>not found</div>;
};

export default NotFound;
