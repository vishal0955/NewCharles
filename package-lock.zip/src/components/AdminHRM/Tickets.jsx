import React from 'react'

const Tickets = () => {
  return (
    <div>
        <h5>Tickets Page  </h5>
        </div>
  )
}

export default Tickets