import SalesOverview from "./SalesOverview";

function App() {
  return <SalesOverview />;
}

export default App;
