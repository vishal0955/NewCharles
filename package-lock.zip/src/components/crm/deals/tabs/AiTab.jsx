import React from 'react';

const AiTab = () => {
  return (
    <div className="p-4">
        <h6>AiTab Data...</h6>
    </div>
  );
};

export default AiTab;
